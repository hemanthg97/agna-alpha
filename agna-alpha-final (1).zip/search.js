document.getElementById("askButton").addEventListener("click", async () => {
  const query = document.getElementById("searchBox").value;

  try {
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });

    const data = await res.json();

    document.getElementById("results").innerHTML = `
      <h3>AI Answer:</h3>
      <p>${data.ai}</p>
      <h3>Latest News:</h3>
      <ul>
        ${data.news.map(n => `<li>${n.title}</li>`).join("")}
      </ul>
    `;
  } catch (err) {
    document.getElementById("results").innerHTML = "Error: " + err.message;
  }
});