export default async function handler(req, res) {
  try {
    const { query } = req.body;

    // Fetch news from NewsAPI
    const newsRes = await fetch(`https://newsapi.org/v2/top-headlines?country=in&apiKey=${process.env.NEWS_API_KEY}`);
    const newsData = await newsRes.json();

    // OpenAI API call
    const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are a helpful assistant answering questions about Indian startup news." },
          { role: "user", content: query }
        ]
      })
    });

    const aiData = await aiRes.json();

    res.status(200).json({
      news: newsData.articles.slice(0, 5),
      ai: aiData.choices[0].message.content
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}